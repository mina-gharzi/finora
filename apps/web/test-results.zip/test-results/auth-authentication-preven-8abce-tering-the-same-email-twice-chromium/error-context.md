# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth.spec.ts >> authentication >> prevents registering the same email twice
- Location: e2e\auth.spec.ts:110:7

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected: "http://127.0.0.1:3000/dashboard"
Received: "http://127.0.0.1:3000/register"
Timeout:  5000ms

Call log:
  - Expect "toHaveURL" with timeout 5000ms
    14 × locator resolved to <html lang="fa" dir="rtl" data-theme="light" class="j535YW_variable">…</html>
       - unexpected value "http://127.0.0.1:3000/register"

```

```yaml
- main:
  - text: فینورا
  - heading "ساخت حساب فینورا" [level=1]
  - paragraph: برای شروع، یک حساب کاربری بسازید.
  - text: نام
  - textbox "نام": کاربر آزمایشی
  - text: ایمیل
  - textbox "ایمیل": user_1792925896988_605715@example.com
  - text: گذرواژه
  - textbox "گذرواژه": Password123
  - paragraph: حداقل ۸ نویسه، شامل یک حرف و یک رقم.
  - button "ثبت‌نام" [disabled]
  - paragraph:
    - text: قبلاً ثبت‌نام کرده‌اید؟
    - link "وارد شوید":
      - /url: /login
- alert
```

# Test source

```ts
  1  | import { expect, type Locator, type Page } from "@playwright/test";
  2  | import { markEmailVerified } from "./db";
  3  | 
  4  | export interface TestCredentials {
  5  |   name: string;
  6  |   email: string;
  7  |   password: string;
  8  | }
  9  | 
  10 | /**
  11 |  * Resolves a text field in the *visible* form.
  12 |  *
  13 |  * Next 16 keeps a prefetched route mounted in a hidden (`display:none`) React
  14 |  * Activity tree, so `getByLabel` can match a hidden duplicate input. Scoping to
  15 |  * `:visible` targets the interactive form.
  16 |  */
  17 | export function field(page: Page, name: string): Locator {
  18 |   return page.locator(`input[name="${name}"]:visible`);
  19 | }
  20 | 
  21 | export function uniqueEmail(prefix = "user"): string {
  22 |   return `${prefix}_${Date.now()}_${Math.floor(Math.random() * 1_000_000)}@example.com`;
  23 | }
  24 | 
  25 | export function makeCredentials(
  26 |   overrides: Partial<TestCredentials> = {},
  27 | ): TestCredentials {
  28 |   return {
  29 |     name: "کاربر آزمایشی",
  30 |     email: uniqueEmail(),
  31 |     password: "Password123",
  32 |     ...overrides,
  33 |   };
  34 | }
  35 | 
  36 | /** Registers a brand-new account through the UI and waits for the dashboard. */
  37 | export async function registerUser(
  38 |   page: Page,
  39 |   credentials: TestCredentials,
  40 | ): Promise<void> {
  41 |   await page.goto("/register");
  42 |   await field(page, "name").fill(credentials.name);
  43 |   await field(page, "email").fill(credentials.email);
  44 |   await field(page, "password").fill(credentials.password);
  45 |   await page.getByRole("button", { name: "ثبت‌نام" }).click();
> 46 |   await expect(page).toHaveURL("/dashboard");
     |                      ^ Error: expect(page).toHaveURL(expected) failed
  47 |   // Financial mutations require a verified email; tests have no inbox, so
  48 |   // apply the verification end state the emailed link would produce.
  49 |   await markEmailVerified(credentials.email);
  50 | }
  51 | 
  52 | /** Registers a throwaway account and leaves the browser signed in. */
  53 | export async function authenticate(page: Page): Promise<TestCredentials> {
  54 |   const credentials = makeCredentials();
  55 |   await registerUser(page, credentials);
  56 |   return credentials;
  57 | }
  58 | 
```